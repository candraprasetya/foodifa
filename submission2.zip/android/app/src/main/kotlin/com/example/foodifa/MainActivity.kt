package com.kardusinfo.foodifa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
