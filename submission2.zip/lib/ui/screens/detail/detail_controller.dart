part of '../screens.dart';

class DetailController extends GetxController {
  late DetailRestaurantModel restaurant;
}
