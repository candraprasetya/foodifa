part of 'utilities.dart';

const baseUrl = 'https://restaurant-api.dicoding.dev/';
const pictureUrl = 'https://restaurant-api.dicoding.dev/images/large/';
