part of 'utilities.dart';

const ANIM_NO_INTERNET = 'assets/animations/no_internet.json';
