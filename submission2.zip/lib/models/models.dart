import 'dart:convert';

part 'restaurant/restaurant_model.dart';
part 'restaurant/detail/detail_restaurant_model.dart';
