import 'package:flutter/material.dart';
import 'package:foodifa/app.dart';

void main() {
  runApp(MyApp());
}
