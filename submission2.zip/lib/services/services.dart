import 'dart:developer';

import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:foodifa/models/models.dart';
import 'package:foodifa/utilities/utilities.dart';
part 'restaurant_services.dart';
